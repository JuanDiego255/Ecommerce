<!-- resources/views/emails/sale.blade.php -->
<!DOCTYPE html>
<html>

<body>
    <div class="receipt-container">
        <div class="receipt-header">
            <h1>Tarjeta de regalo</h1>
        </div>
        <div class="receipt-body">
           
        </div>
        <hr>
        <div class="receipt-footer">
           
        </div>
    </div>
</body>

</html>
